package org.felines;

public interface Animal extends AnimalSuper {
}
