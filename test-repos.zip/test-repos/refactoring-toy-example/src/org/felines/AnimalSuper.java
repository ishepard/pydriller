package org.felines;

public interface AnimalSuper {

	void action();

}