package org.birds;

public class Bird {

	public void layEgg() {
		
	}

}
