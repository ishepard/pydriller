package org.animals;

public class Labrador extends Dog {
	
}
