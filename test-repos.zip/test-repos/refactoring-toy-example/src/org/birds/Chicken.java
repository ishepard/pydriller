package org.birds;

public class Chicken extends Bird {

	public void cackle() {
		System.out.println("cackle");
	}

}
