package org.birds;

public class Duck extends Bird {

	public void quack() {
		System.out.println("quack");
	}

}
