class Arquivo {
  void a() {
   b();
   c();
   d();
  }
   int a;
   int b;
}
