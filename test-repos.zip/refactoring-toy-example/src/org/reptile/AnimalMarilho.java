package org.reptile;

public class AnimalMarilho {

	public AnimalMarilho() {
		super();
	}
	
	protected int spead;
	protected String action;

	

	public int getSpead() {
		return spead;
	}

	public void setSpead(int spead) {
		this.spead = spead;
	}

	public String getAction() {
		return action;
	}

	public void setAction(String action) {
		this.action = action;
	}

}