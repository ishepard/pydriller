package org.animals;

public class Poodle extends Dog {

}
