package org.animals;

public class CowRenamed {

	public void moo() {
		System.out.println("moo");
	}
	
	public void eat() {
		System.out.println("eat");
	} 
}
