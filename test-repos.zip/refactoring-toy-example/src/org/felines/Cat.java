package org.felines;


public class Cat extends Feline implements Animal{

	
	public void sleep(){
		int s1 = 1;
		int s2 = 2;
		sleepNight();
		int s8 = 8;
		
	}

	private void sleepNight() {
		int s3 = 3;
		int s4 = 4;
		int s5 = 5;
		int s6 = 6;
		int s7 = 7;
	}

}
