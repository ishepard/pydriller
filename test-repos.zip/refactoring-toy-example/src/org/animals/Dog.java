package org.animals;


public class Dog {

	private int age = 0;
	public int magicNumber = 17;

	public int getAge() {
		return this.age;
	}

	public void takeABreath() {
		System.out.println("...");
	}

}
